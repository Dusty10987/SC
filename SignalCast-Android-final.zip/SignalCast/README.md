# SignalCast

SignalCast is a polished, receive-only Android audio client for an **authorized audio feed or gateway**. It is designed for situations where a radio/receiver or agency-approved gateway has already turned the radio system into an audio stream.

## Design

```text
Authorized radio/receiver/gateway
              |
              | audio stream
              v
        SignalCast Android
              |
              v
        Device speakers
```

The app deliberately does not connect to GATRRS as a subscriber, perform P25 trunking, accept encryption keys, decrypt protected radio traffic, or transmit/PTT.

## Current capabilities

- Professional red/blue dark UI
- Receive-only playback
- Direct HTTPS audio streams
- RTSP network streams
- HLS endpoints when provided by the authorized gateway
- MP3/Icecast-style live audio
- ICY metadata display when the source supplies it
- Android background playback via `MediaSessionService`
- System media controls/notification
- Persistent feed name, URL, and volume
- Bundled local audio test
- Connection/buffering/error state display

## Why the app is structured this way

Broadcastify documents an audio-feed architecture where a receiver/gateway sends audio to an Icecast-style server. Their feed-provider documentation describes MPEG/MP3 audio and an Icecast source configuration. SignalCast uses the same *kind* of listener-side pattern—an audio stream in, player out—without scraping or redistributing Broadcastify's live catalog.

As of June 2026, Broadcastify says its Live Audio Feed Catalog API is reviewed/paid and explicitly says it is not licensing new consumer-facing police-scanner applications or live-audio redistribution. SignalCast therefore does not include a Broadcastify catalog wrapper or a scraped feed directory.

## Tech stack

- Java 17
- Android Gradle Plugin 9.4.0
- Gradle 9.6.1
- compileSdk / targetSdk 36
- AndroidX Media3 1.11.1
- Media3 ExoPlayer + Session + HLS + RTSP

## Build

See `docs/BUILD_ANDROID.md`.

## Security boundary

The feed URL should be an endpoint that the user is authorized to access. Keep credentials out of source control. Prefer HTTPS. SignalCast does not store radio encryption keys or radio-system credentials.

## Project note

The execution environment used to prepare this project did not include an Android SDK or external dependency access, so an APK could not be compiled here. The project includes a GitHub Actions workflow that can perform a clean Android build on a standard hosted runner.

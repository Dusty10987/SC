# SignalCast architecture

SignalCast is intentionally a **receive-only audio client**. The radio-system side is external to the app.

```text
P25 radio / authorized gateway
            │
            ▼
     authorized audio output
            │
         HTTPS audio
            │
            ▼
     SignalCast Android app
            │
      Media3 / ExoPlayer
            │
            ▼
       phone audio system
```

## Broadcastify-style feed model

Broadcastify's current broadcaster documentation describes a dedicated receiver/radio feeding audio into streaming software, and its documented live audio feeds commonly use MP3 at 22.05 kHz with 16 kbps mono or 32 kbps stereo. SignalCast therefore treats a direct audio stream as the client boundary rather than implementing a radio-system protocol.

Broadcastify's current developer catalog API is limited to approved licensees and requires an application key. SignalCast does not embed or assume one. If an approved API key is later supplied, a catalog module can be added without changing the player.

## Supported client input

The first release accepts a direct `https://` URL. Media3/ExoPlayer handles progressive audio such as MP3 and adaptive formats such as HLS when the source provides them.

The app also reads ICY in-stream metadata when supplied by the source and shows the title in the Now Playing area.

## Why the app does not implement P25/GATRRS access

The project is designed around the authorized output supplied to the listener app. It deliberately has no P25 trunking implementation, no radio-network login, no AES key handling, and no PTT/transmit path.

That separation also makes the app reusable with a department gateway, a private authorized stream, an approved public feed, or another documented audio service.

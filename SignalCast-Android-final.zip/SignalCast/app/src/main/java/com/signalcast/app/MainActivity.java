package com.signalcast.app;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Metadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.extractor.metadata.icy.IcyInfo;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;

import com.google.common.util.concurrent.ListenableFuture;

public final class MainActivity extends Activity {
    private static final int NOTIFICATION_REQUEST = 100;
    private static final String PREFS = "signalcast_prefs";
    private static final String PREF_NAME = "feed_name";
    private static final String PREF_URL = "feed_url";
    private static final String PREF_VOLUME = "feed_volume";
    private static final long STATUS_TICK_MS = 1000L;

    private EditText nameInput;
    private EditText urlInput;
    private TextView feedTitle;
    private TextView nowPlaying;
    private TextView statusText;
    private TextView uptimeText;
    private TextView sourceTypeText;
    private SeekBar volumeSeek;
    private Button connectButton;
    private Button disconnectButton;
    private Button testButton;

    private ListenableFuture<MediaController> controllerFuture;
    private MediaController controller;
    private long connectedAtMs = 0L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable statusTicker = new Runnable() {
        @Override
        public void run() {
            updateStatus();
            handler.postDelayed(this, STATUS_TICK_MS);
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bindViews();
        loadPrefs();
        requestNotificationPermission();
        connectToMediaSession();
        handler.post(statusTicker);

        connectButton.setOnClickListener(v -> connectFeed());
        disconnectButton.setOnClickListener(v -> stopFeed());
        testButton.setOnClickListener(v -> playLocalTestTone());

        volumeSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && controller != null) {
                    controller.setVolume(progress / 100f);
                    saveVolume(progress);
                }
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
    }

    private void bindViews() {
        nameInput = findViewById(R.id.nameInput);
        urlInput = findViewById(R.id.urlInput);
        feedTitle = findViewById(R.id.feedTitle);
        nowPlaying = findViewById(R.id.nowPlaying);
        statusText = findViewById(R.id.statusText);
        uptimeText = findViewById(R.id.uptimeText);
        sourceTypeText = findViewById(R.id.sourceTypeText);
        volumeSeek = findViewById(R.id.volumeSeek);
        connectButton = findViewById(R.id.connectButton);
        disconnectButton = findViewById(R.id.disconnectButton);
        testButton = findViewById(R.id.testButton);
    }

    private void loadPrefs() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        nameInput.setText(prefs.getString(PREF_NAME, "Authorized live feed"));
        urlInput.setText(prefs.getString(PREF_URL, ""));
        volumeSeek.setProgress(prefs.getInt(PREF_VOLUME, 80));
    }

    private void savePrefs(String name, String url) {
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putString(PREF_NAME, name)
                .putString(PREF_URL, url)
                .apply();
    }

    private void saveVolume(int volume) {
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putInt(PREF_VOLUME, volume)
                .apply();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    NOTIFICATION_REQUEST
            );
        }
    }

    private void connectToMediaSession() {
        SessionToken token = new SessionToken(
                this,
                new ComponentName(this, PlaybackService.class)
        );

        controllerFuture = new MediaController.Builder(this, token).buildAsync();
        controllerFuture.addListener(() -> {
            try {
                controller = controllerFuture.get();
                controller.addListener(new Player.Listener() {
                    @Override
                    public void onIsPlayingChanged(boolean isPlaying) {
                        if (isPlaying && connectedAtMs == 0L) {
                            connectedAtMs = System.currentTimeMillis();
                        }
                        updateStatus();
                    }

                    @Override
                    public void onPlaybackStateChanged(int playbackState) {
                        if (playbackState == Player.STATE_BUFFERING) {
                            statusText.setText("BUFFERING");
                        } else if (playbackState == Player.STATE_READY && controller != null && controller.isPlaying()) {
                            statusText.setText("LIVE • RECEIVING AUDIO");
                        }
                        updateStatus();
                    }

                    @Override
                    public void onMediaItemTransition(@Nullable MediaItem mediaItem, int reason) {
                        updateFeedMetadata();
                    }

                    @Override
                    public void onMediaMetadataChanged(MediaMetadata mediaMetadata) {
                        if (mediaMetadata.title != null) {
                            nowPlaying.setText(mediaMetadata.title);
                        }
                    }

                    @Override
                    public void onMetadata(Metadata metadata) {
                        for (int i = 0; i < metadata.length(); i++) {
                            Metadata.Entry entry = metadata.get(i);
                            if (entry instanceof IcyInfo) {
                                IcyInfo info = (IcyInfo) entry;
                                if (info.title != null && !info.title.isEmpty()) {
                                    nowPlaying.setText(info.title);
                                }
                            }
                        }
                    }

                    @Override
                    public void onPlayerError(PlaybackException error) {
                        connectedAtMs = 0L;
                        statusText.setText("ERROR • " + friendlyError(error));
                        uptimeText.setText("Not connected");
                    }
                });
                controller.setVolume(volumeSeek.getProgress() / 100f);
                updateStatus();
            } catch (Exception e) {
                statusText.setText("ERROR • Playback service unavailable");
            }
        }, command -> runOnUiThread(command));
    }

    private void connectFeed() {
        String name = nameInput.getText().toString().trim();
        String url = urlInput.getText().toString().trim();

        if (name.isEmpty()) {
            name = "Authorized live feed";
        }

        if (!isValidStreamUrl(url)) {
            statusText.setText("ERROR • Use a valid HTTPS or RTSP audio URL");
            Toast.makeText(this, "Use the endpoint supplied by your authorized feed or gateway.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (controller == null) {
            statusText.setText("CONNECTING • Playback service starting");
            return;
        }

        savePrefs(name, url);
        feedTitle.setText(name);
        nowPlaying.setText("Awaiting stream metadata…");
        sourceTypeText.setText(detectSourceLabel(url));
        connectedAtMs = System.currentTimeMillis();
        statusText.setText("CONNECTING");

        MediaItem item = new MediaItem.Builder()
                .setUri(Uri.parse(url))
                .setMediaMetadata(new MediaMetadata.Builder()
                        .setTitle(name)
                        .setArtist("SignalCast")
                        .build())
                .build();

        controller.setMediaItem(item);
        controller.setVolume(volumeSeek.getProgress() / 100f);
        controller.prepare();
        controller.play();
    }

    private void playLocalTestTone() {
        if (controller == null) {
            statusText.setText("ERROR • Playback service unavailable");
            return;
        }
        savePrefs("SignalCast audio test", "");
        feedTitle.setText("SignalCast audio test");
        nowPlaying.setText("Local test tone");
        sourceTypeText.setText("LOCAL TEST");
        connectedAtMs = System.currentTimeMillis();
        statusText.setText("TESTING");

        MediaItem item = MediaItem.fromUri("android.resource://" + getPackageName() + "/" + R.raw.signalcast_test);
        controller.setMediaItem(item);
        controller.setVolume(volumeSeek.getProgress() / 100f);
        controller.prepare();
        controller.play();
    }

    private void stopFeed() {
        if (controller != null) {
            controller.stop();
            connectedAtMs = 0L;
        }
        statusText.setText("STOPPED");
        uptimeText.setText("Not connected");
    }

    private boolean isValidStreamUrl(String raw) {
        try {
            Uri uri = Uri.parse(raw);
            String scheme = uri.getScheme();
            boolean supportedScheme = "https".equalsIgnoreCase(scheme)
                    || "rtsp".equalsIgnoreCase(scheme);
            return supportedScheme
                    && uri.getHost() != null
                    && !uri.getHost().isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    private String detectSourceLabel(String url) {
        String lower = url.toLowerCase();
        if (lower.contains(".m3u8")) return "HTTPS • HLS";
        if (lower.startsWith("rtsp://")) return "RTSP • NETWORK STREAM";
        if (lower.contains(".mp3") || lower.contains("audio")) return "HTTPS • MP3/AUDIO";
        return "HTTPS • AUTO DETECT";
    }

    private void updateStatus() {
        if (controller == null) return;

        if (controller.isPlaying()) {
            statusText.setText("LIVE • RECEIVING AUDIO");
            updateUptime();
        } else if (controller.getPlaybackState() == Player.STATE_BUFFERING) {
            statusText.setText("BUFFERING");
            updateUptime();
        } else if (controller.getPlaybackState() == Player.STATE_ENDED) {
            statusText.setText("ENDED");
            uptimeText.setText("Not connected");
            connectedAtMs = 0L;
        } else {
            statusText.setText("READY");
            uptimeText.setText("Not connected");
        }
    }

    private void updateUptime() {
        if (connectedAtMs == 0L) {
            uptimeText.setText("Connecting…");
            return;
        }
        long elapsed = Math.max(0L, System.currentTimeMillis() - connectedAtMs) / 1000L;
        long hours = elapsed / 3600L;
        long minutes = (elapsed % 3600L) / 60L;
        long seconds = elapsed % 60L;
        if (hours > 0) {
            uptimeText.setText(String.format("Connected %dh %02dm %02ds", hours, minutes, seconds));
        } else {
            uptimeText.setText(String.format("Connected %02dm %02ds", minutes, seconds));
        }
    }

    private void updateFeedMetadata() {
        if (controller == null) return;
        MediaMetadata metadata = controller.getMediaMetadata();
        if (metadata.title != null) {
            nowPlaying.setText(metadata.title);
        }
    }

    private String friendlyError(PlaybackException error) {
        switch (error.errorCode) {
            case PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED:
                return "network connection failed";
            case PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS:
                return "server rejected the request";
            case PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND:
                return "stream URL not found";
            case PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED:
                return "unsupported or malformed audio stream";
            default:
                return "stream could not be played";
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(statusTicker);
        if (controllerFuture != null) {
            MediaController.releaseFuture(controllerFuture);
        }
        controller = null;
        super.onDestroy();
    }
}

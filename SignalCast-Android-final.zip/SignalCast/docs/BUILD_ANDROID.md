# Building SignalCast on Android

## Android Studio (recommended)

1. Install a current Android Studio release.
2. Open the `SignalCast` folder.
3. Let Android Studio sync Gradle and download the AndroidX Media3 dependencies.
4. Make sure an Android SDK Platform 36 and Build Tools 36.0.0 are installed.
5. Use JDK 17 for the Gradle JDK.
6. Select a physical Android device or emulator and press Run.
7. The app includes a bundled `RUN AUDIO TEST` button, so it can be verified before any network feed is configured.

## Command line

A local Gradle installation can build the project with:

```text
gradle --no-daemon assembleDebug
```

The APK is written to:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions

The repository contains `.github/workflows/build-debug.yml`. Push the project to a GitHub repository, open **Actions**, choose **Build SignalCast**, and run the workflow. The workflow installs JDK 17, Android API 36/build tools 36.0.0, Gradle 9.6.1, builds `assembleDebug`, and uploads the APK as a workflow artifact.

## Feed configuration

SignalCast is intentionally an audio client, not a P25 radio-network client. Enter the URL supplied by the authorized audio gateway/feed. Supported entry schemes are `https://` and `rtsp://`.

Typical authorized gateway formats can include a direct MP3/Icecast-style stream or an HLS endpoint. The app does not implement P25 trunking, radio registration, AES key handling/decryption, or PTT/transmit functions.
